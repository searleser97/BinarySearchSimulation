# Binary Search Simulation

Python program to visualize the behavior of upper_bound and lower_bound binary searches.

<table>
  <tr>
    <th>Upper Bound</th>
    <th>Lower Bound</th>
  </tr>
  <tr>
    <td>
      <img src="https://searleser97.github.io/BinarySearchSimulation/upper_bound.png" width="250" height="400" />
    </td>
    <td>
      <img src="https://searleser97.github.io/BinarySearchSimulation/lower_bound.png" width="250" height="400" />
    </td>
  </tr>
</table>