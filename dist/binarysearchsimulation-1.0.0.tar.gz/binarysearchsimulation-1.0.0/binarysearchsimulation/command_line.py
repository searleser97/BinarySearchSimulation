#!/usr/bin/env python3

from binarysearchsimulation import Simulation


def main():
    Simulation().run()
