#!/usr/bin/env python3

from binarysearchsimulation.Simulation import Simulation


def main():
    Simulation().run()
